// lib/firebase_options.dart
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    // if (kIsWeb) {
    //   return web;
    // }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      // case TargetPlatform.iOS:
      //   return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
              'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
              'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
              'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not configured for this platform.',
        );
    }
  }

  // ✅ Android options (من البيانات التي أرسلتها)
  static const FirebaseOptions android = FirebaseOptions(
    // apiKey: 'AIzaSyB_Dv0E3VqUqwggdGj746w7Un3tv7gi888',
    apiKey: 'AIzaSyDMs6jrG0E-OI6bSByt9SJWAT5eljJ9rtY',
    appId: '1:1089159504691:android:caf0b28502cdcbe57e5446',
    messagingSenderId: '1089159504691',
    projectId: 'almashe-run',
    storageBucket: 'almashe-run.firebasestorage.app',
  );

  // // ✅ Web options (مستندة على نفس المشروع - أضفها للتكامل)
  // static const FirebaseOptions web = FirebaseOptions(
  //   apiKey: 'AIzaSyB_Dv0E3VqUqwggdGj746w7Un3tv7gi888',
  //   appId: '1:1089159504691:web:caf0b28502cdcbe57e5446', // هذا مختلف للويب
  //   messagingSenderId: '1089159504691',
  //   projectId: 'almashe-run',
  //   authDomain: 'almashe-run.firebaseapp.com',
  //   storageBucket: 'almashe-run.firebasestorage.app',
  // );
  //
  // // ✅ iOS options (إذا كنت تخطط لدعم iOS لاحقاً)
  // static const FirebaseOptions ios = FirebaseOptions(
  //   apiKey: 'AIzaSyB_Dv0E3VqUqwggdGj746w7Un3tv7gi888',
  //   appId: '1:1089159504691:ios:caf0b28502cdcbe57e5446', // هذا مختلف لـ iOS
  //   messagingSenderId: '1089159504691',
  //   projectId: 'almashe-run',
  //   storageBucket: 'almashe-run.firebasestorage.app',
  //   iosBundleId: 'com.almashe.run', // ✅ هذا مهم - غيّره حسب Bundle ID الخاص بك
  // );
}