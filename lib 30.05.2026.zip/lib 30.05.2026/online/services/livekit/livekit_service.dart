import 'package:livekit_client/livekit_client.dart';
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

import '../../models/online_character_system.dart';

class LiveKitGameService {
  static final LiveKitGameService _instance = LiveKitGameService._internal();
  factory LiveKitGameService() => _instance;
  LiveKitGameService._internal();

  // ⚠️ ضع مفاتيح LiveKit الحقيقية هنا (من Dashboard)
  static const String LIVEKIT_API_KEY = "APIYPoXPHJtZwAF";
  static const String LIVEKIT_API_SECRET = "W2833ayx8Luh2Vg8okyuLfQuLUA2QkuAJi8WBRuFnbP";
  static const String LIVEKIT_URL = "wss://project-3almashe-run-ai23cs02.livekit.cloud";

  Room? _room;
  Room? get room => _room;

  LocalParticipant? _localParticipant;
  bool _isConnected = false;
  bool _isHost = false;
  String? _currentRoomId;
  String? _myPlayerId;

  // Callbacks للاعبين الآخرين
  Function(Map<String, dynamic>)? onPlayerStateReceived;
  Function(Map<String, dynamic>)? onAttackReceived;
  Function(Map<String, dynamic>)? onGameEndReceived;
  Function(Map<String, dynamic>)? onPlatformsReceived;  // ✅ أضف هذا

  bool get isConnected => _isConnected;
  String? get roomId => _currentRoomId;
  bool get isHost => _isHost;

  // ============================================================
  // ✅ توليد Token مباشرة (بدون Firebase)
  // ============================================================
  String _generateToken(String roomName, String participantName) {
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final exp = now + 3600;

    final header = {
      "alg": "HS256",
      "typ": "JWT",
    };

    final payload = {
      "iss": LIVEKIT_API_KEY,
      "name": participantName,
      "video": {
        "room": roomName,
        "roomJoin": true,
        "canPublish": true,
        "canSubscribe": true,
        "canPublishData": true,
      },
      "exp": exp,
      "nbf": now,
      "sub": participantName,
    };

    final encodedHeader = _base64UrlEncode(utf8.encode(jsonEncode(header)));
    final encodedPayload = _base64UrlEncode(utf8.encode(jsonEncode(payload)));
    final signature = _hmacSha256("$encodedHeader.$encodedPayload", LIVEKIT_API_SECRET);

    return "$encodedHeader.$encodedPayload.$signature";
  }

  String _base64UrlEncode(List<int> bytes) {
    return base64Url.encode(bytes).replaceAll('=', '');
  }

  String _hmacSha256(String data, String secret) {
    final key = utf8.encode(secret);
    final bytes = utf8.encode(data);
    final hmac = Hmac(sha256, key);
    final digest = hmac.convert(bytes);
    return base64Url.encode(digest.bytes);
  }

  // ============================================================
  // ✅ الاتصال بالغرفة
  // ============================================================
  Future<bool> connectToRoom({
    required String roomId,
    required String playerId,
    required bool isHost,
  }) async {
    try {
      _isHost = isHost;
      _currentRoomId = roomId;
      _myPlayerId = playerId;

      print('🔌 [LiveKit] جاري الاتصال بالغرفة: $roomId');
      print('   👤 معرف اللاعب: $playerId');
      print('   👑 دوري: ${isHost ? "مضيف" : "ضيف"}');

      final token = _generateToken(roomId, playerId);
      _room = Room();

      _room?.events.listen((event) {
        print('📡 [LiveKit Event]: ${event.runtimeType}');

        if (event is DataReceivedEvent) {
          _onDataReceived(event.data);
        }

        if (event is RoomConnectedEvent) {
          print('✅ [LiveKit] تم الاتصال بالغرفة بنجاح');
          _isConnected = true;
        }

        if (event is RoomDisconnectedEvent) {
          print('🔌 [LiveKit] تم قطع الاتصال');
          _isConnected = false;
        }
      });

      await _room?.connect(LIVEKIT_URL, token);
      _localParticipant = _room?.localParticipant;

      print('✅ [LiveKit] تم الاتصال بنجاح');
      return true;

    } catch (e, stack) {
      print('❌ [LiveKit] فشل الاتصال: $e');
      print(stack);
      return false;
    }
  }

  // ============================================================
  // ✅ إرسال حالة اللاعب
  // ============================================================
  void sendPlayerState({
    required double x,
    required double y,
    required double health,
    required int frame,
  }) {
    if (!_isConnected || _room == null) {
      print('⚠️ [LiveKit] لا يمكن الإرسال');
      return;
    }

    final data = utf8.encode(jsonEncode({
      'type': 'player_state',
      'playerId': _myPlayerId,
      'x': x,
      'y': y,
      'health': health,
      'frame': frame,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    }));

    try {
      _room?.localParticipant?.publishData(data, reliable: false);
      print('📤 [LiveKit] تم إرسال حالة اللاعب: x=$x, y=$y');
    } catch (e) {
      print('❌ [LiveKit] فشل إرسال الحالة: $e');
    }
  }

  // ============================================================
  // ✅ إرسال هجوم
  // ============================================================
  void sendAttack({
    required double x,
    required double y,
    required int damage,
    required String weaponType,
    required bool isFacingRight,
  }) {
    if (!_isConnected || _room == null) return;

    final data = utf8.encode(jsonEncode({
      'type': 'attack',
      'playerId': _myPlayerId,
      'x': x,
      'y': y,
      'damage': damage,
      'weaponType': weaponType,
      'isFacingRight': isFacingRight,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    }));

    _room?.localParticipant?.publishData(data, reliable: true);
    print('⚔️ [LiveKit] تم إرسال هجوم: $weaponType ضرر $damage');
  }

  // ============================================================
  // ✅ إرسال نهاية اللعبة
  // ============================================================
  void sendGameEnd({required String winner, required String reason}) {
    if (!_isConnected || _room == null) return;

    final data = utf8.encode(jsonEncode({
      'type': 'game_end',
      'playerId': _myPlayerId,
      'winner': winner,
      'reason': reason,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    }));

    _room?.localParticipant?.publishData(data, reliable: true);
    print('🏆 [LiveKit] تم إرسال نهاية اللعبة: الفائز=$winner');
  }

  // ============================================================
  // ✅ إرسال المنصات
  // ============================================================
  void sendPlatforms(List<BattlePlatform> platforms, String patternName) {
    if (!_isConnected || _room == null) return;

    final platformsData = platforms.map((p) => {
      'x': p.x,
      'y': p.y,
      'width': p.width,
      'height': p.height,
      'type': p.type,
      'color': p.color.value,
    }).toList();

    final data = utf8.encode(jsonEncode({
      'type': 'platforms_sync',
      'playerId': _myPlayerId,
      'platforms': platformsData,
      'patternName': patternName,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    }));

    _room?.localParticipant?.publishData(data, reliable: true);
    print('📤 [LiveKit] تم إرسال ${platforms.length} منصة');
  }

  // ============================================================
  // ✅ معالجة البيانات الواردة
  // ============================================================
  void _onDataReceived(List<int> rawData) {
    try {
      final jsonString = utf8.decode(rawData);
      final data = jsonDecode(jsonString);

      final type = data['type'] as String;
      final playerId = data['playerId'] as String?;

      if (playerId == _myPlayerId) return;

      switch (type) {
        case 'player_state':
          onPlayerStateReceived?.call(data);
          break;
        case 'attack':
          onAttackReceived?.call(data);
          break;
        case 'game_end':
          print('🏆 [LIVEKIT] استلام نهاية اللعبة');
          onGameEndReceived?.call(data);
          break;
        case 'platforms_sync':
          print('📥 [LiveKit] استلام منصات من الخصم');
          onPlatformsReceived?.call(data);
          break;
        default:
          print('⚠️ [LiveKit] نوع غير معروف: $type');
      }
    } catch (e) {
      print('⚠️ [LiveKit] خطأ في معالجة البيانات: $e');
    }
  }

  // ============================================================
  // ✅ قطع الاتصال
  // ============================================================
  Future<void> disconnect() async {
    await _room?.disconnect();
    _isConnected = false;
    _room = null;
    _localParticipant = null;
    print('🔌 [LiveKit] تم قطع الاتصال');
  }
}